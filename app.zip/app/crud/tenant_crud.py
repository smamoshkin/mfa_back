from sqlalchemy.orm import Session
from app.models.tenant import Tenant
from app.schemas.tenant import TenantCreate, TenantUpdate
from fastapi import HTTPException, status
from datetime import datetime
from app.core.auth import get_password_hash

def get_tenant_by_email(db: Session, email: str):
    """Получить тенанта по email"""
    return db.query(Tenant).filter(Tenant.login_email == email).first()

def get_tenant(db: Session, tenant_id: int):
    # Возвращает тенанта по ID или None
    return db.query(Tenant).filter(Tenant.id == tenant_id).first()

def get_tenants(db: Session, skip: int = 0, limit: int = 100):
    # Возвращает список тенантов с пагинацией
    return db.query(Tenant).offset(skip).limit(limit).all()

def create_tenant(db: Session, tenant: TenantCreate):
    # Проверяем, существует ли уже тенант с таким email
    db_tenant = get_tenant_by_email(db, email=tenant.login_email)
    if db_tenant:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tenant with this email already exists"
        )
    
    # Создаем словарь данных, исключая пароль
    tenant_data = tenant.model_dump(exclude={'password'})
    
    # Добавляем хешированный пароль и дату создания
    tenant_data['hashed_password'] = get_password_hash(tenant.password)
    tenant_data['created_at'] = datetime.utcnow()  # 👈 Явно устанавливаем дату
    
    # Создаем нового тенанта в БД
    db_tenant = Tenant(**tenant_data)
    db.add(db_tenant)
    db.commit()
    db.refresh(db_tenant) # Обновляем объект данными из БД (чтобы получить id и timestamps)
    return db_tenant

def update_tenant(db: Session, tenant_id: int, tenant: TenantUpdate):
    # Обновляет данные тенанта
    db_tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not db_tenant:
        return None
    
    # Если обновляется email, проверяем его уникальность
    if tenant.login_email and tenant.login_email != db_tenant.login_email:
        existing_tenant = get_tenant_by_email(db, email=tenant.login_email)
        if existing_tenant:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tenant with this email already exists"
            )
    
    # Обновляем только переданные поля
    update_data = tenant.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_tenant, field, value)
    
    db.commit()
    db.refresh(db_tenant)
    return db_tenant

def delete_tenant(db: Session, tenant_id: int):
    # Удаляет тенанта
    db_tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not db_tenant:
        return None
    db.delete(db_tenant)
    db.commit()
    return db_tenant

def set_wb_api_key(db: Session, tenant_id: int, wb_api_key: str):
    """Установить API ключ для WB"""
    db_tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not db_tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant with tenant_id={tenant_id} not found"
        )
    
    db_tenant.wb_api_key = wb_api_key
    db_tenant.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(db_tenant)
    return db_tenant