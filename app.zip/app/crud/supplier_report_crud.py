from sqlalchemy.orm import Session
from sqlalchemy import insert
from fastapi import HTTPException, status
from app.models.supplier_report import SupplierReport
from app.models.tenant import Tenant
from app.schemas.supplier_report import SupplierReportCreate
from typing import List
from datetime import date
import logging
import time

logger = logging.getLogger(__name__)

def get_supplier_report(db: Session, report_id: int):
    """Получить отчет по ID"""
    return db.query(SupplierReport).filter(SupplierReport.id == report_id).first()

def get_reports_by_tenant(db: Session, tenant_id: int, skip: int = 0, limit: int = 100):
    """Получить все отчеты tenant'а"""
    return db.query(SupplierReport).filter(
        SupplierReport.tenant_id == tenant_id
    ).order_by(
        SupplierReport.sale_dt.desc()
    ).offset(skip).limit(limit).all()

def get_reports_by_period(db: Session, tenant_id: int, date_from: date, date_to: date):
    """Получить отчеты за период"""
    return db.query(SupplierReport).filter(
        SupplierReport.tenant_id == tenant_id,
        SupplierReport.sale_dt >= date_from,
        SupplierReport.sale_dt <= date_to
    ).order_by(SupplierReport.sale_dt).all()

def create_supplier_report(db: Session, report: SupplierReportCreate):
    """Создать новый отчет"""
    
    # Проверяем существование tenant'а
    db_tenant = db.query(Tenant).filter(Tenant.id == report.tenant_id).first()
    if not db_tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant with id {report.tenant_id} not found"
        )
    
    # Проверяем уникальность rrd_id в рамках tenant'а
    if report.rrd_id:
        existing_report = db.query(SupplierReport).filter(
            SupplierReport.tenant_id == report.tenant_id,
            SupplierReport.rrd_id == report.rrd_id
        ).first()
        if existing_report:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Report with this rrd_id already exists"
            )
    
    db_report = SupplierReport(**report.model_dump())
    db.add(db_report)
    db.commit()
    db.refresh(db_report)
    return db_report


def bulk_create_reports(db: Session, reports: List[SupplierReportCreate]):
    """Массовая вставка с внутренним батчингом"""
    if not reports:
        return 0
    
    total_inserted = 0
    batch_size = 10000  # 👈 ВСТАВЛЯЕМ ПО 10000 ЗАПИСЕЙ
    try:
        for i in range(0, len(reports), batch_size):
            batch = reports[i:i + batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (len(reports) + batch_size - 1) // batch_size
            reports_data = [report.model_dump() for report in batch]
            
            stmt = insert(SupplierReport).values(reports_data)
            logger.info(f"📦 Processing batch {batch_num}/{total_batches} with {len(batch)} records")
            start_time = time.time()
            result = db.execute(stmt)
            db.commit()
            
            insert_time = time.time() - start_time
            total_inserted += len(batch)
            
            logger.info(f"✅ Batch {i//batch_size + 1}: inserted {len(batch)} records in {insert_time:.2f}s")
        
        logger.info(f"🎯 Total inserted: {total_inserted} records in {len(reports)//batch_size + 1} batches")
        return total_inserted
    except Exception as e:
        logger.error(f"❌ Bulk insert failed at batch {batch_num}: {str(e)}")
        logger.error(f"🔍 Failed batch details: {len(batch)} records")
        raise