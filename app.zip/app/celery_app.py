from celery import Celery
import os
from dotenv import load_dotenv

load_dotenv()

# Создаем Celery приложение
celery_app = Celery(
    'marketfinance',
    broker='redis://94.103.91.204:6379/0',  
    backend='redis://94.103.91.204:6379/0',
    include=['app.tasks.sync_tasks']
)

# Конфигурация
celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='Europe/Moscow',
    enable_utc=True,
    task_routes={
        'app.tasks.sync_tasks.sync_tenant_wb_data': {'queue': 'wb_sync'},  
    }
)