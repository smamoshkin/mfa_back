from fastapi import APIRouter, BackgroundTasks
from app.tasks.sync_tasks import sync_tenant_wb_data
from datetime import date
from typing import List

router = APIRouter(
    prefix="/tasks",
    tags=["tasks"]
)

@router.post("/sync/wb/{tenant_id}")
def start_sync_task(
    tenant_id: int,
    date_from: date,
    date_to: date
):
    """
    Запуск фоновой задачи синхронизации WB за любой период
    """
    task = sync_tenant_wb_data.delay(  # 👈 Используем универсальную задачу
        tenant_id=tenant_id,
        date_from=date_from.isoformat(),
        date_to=date_to.isoformat()
    )
    
    return {
        "status": "started",
        "task_id": task.id,
        "tenant_id": tenant_id,
        "period": f"{date_from} to {date_to}"
    }

@router.get("/status/{task_id}")  # 👈 ЭТОТ ЭНДПОИНТ ДОЛЖЕН БЫТЬ!
def get_task_status(task_id: str):
    """Проверка статуса задачи"""
    task = sync_tenant_wb_data.AsyncResult(task_id)
    
    return {
        "task_id": task_id,
        "status": task.status,
        "result": task.result if task.ready() else None
    }