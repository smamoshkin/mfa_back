from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from datetime import date
from typing import Optional

from app.database.database import get_db
from app.models.tenant import Tenant
from app.services.sync_service import SyncService

router = APIRouter(
    prefix="/sync",
    tags=["sync"]
)

@router.post("/wb/{tenant_id}")
async def sync_wb_data(
    tenant_id: int,
    date_from: date,
    date_to: date,
    db: Session = Depends(get_db)
):
    """
    Запуск синхронизации данных WB за указанный период
    """
    # 1. Находим tenant
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(404, "Tenant not found")
    
    if not tenant.wb_api_key:
        raise HTTPException(400, "WB API Key not configured for this tenant")
    
    # 2. Запускаем синхронизацию
    sync_service = SyncService()
    
    try:
        metrics = await sync_service.sync_wb_data_for_period(
            db=db,
            tenant=tenant,
            date_from=date_from,
            date_to=date_to
        )
        
        return {
            "status": "success",
            "tenant_id": tenant_id,
            "period": f"{date_from} to {date_to}",
            "metrics": metrics  # 👈 Возвращаем метрики
        }
        
    except Exception as e:
        raise HTTPException(500, f"Sync failed: {str(e)}")

@router.post("/wb/{tenant_id}/background")
async def sync_wb_data_background(
    tenant_id: int,
    date_from: date,
    date_to: date,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Запуск синхронизации в фоновом режиме
    """
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(404, "Tenant not found")
    
    if not tenant.wb_api_key:
        raise HTTPException(400, "WB API Key not configured for this tenant")
    
    # Добавляем в фоновые задачи
    sync_service = SyncService()
    background_tasks.add_task(
        sync_service.sync_wb_data_for_period,
        db, tenant, date_from, date_to
    )
    
    return {
        "status": "started", 
        "message": "Sync started in background",
        "tenant_id": tenant_id,
        "period": f"{date_from} to {date_to}"
    }