from sqlalchemy import Column, Integer, String, DateTime, Boolean, Index, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .base import Base
from datetime import datetime

class Tenant(Base):
    __tablename__ = "tenants"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    
    # 👇 ОДИН email для всего
    login_email = Column(String(255), nullable=False, unique=True, index=True)
    
    # 👇 Поля для аутентификации
    hashed_password = Column(String(255))
    
    # API ключи
    wb_api_key = Column(String(500), nullable=True)
    ozon_api_key = Column(String(500), nullable=True)
    
    # Статусы
    is_active = Column(Boolean, default=True)
    email_verified = Column(Boolean, default=False)
    
    # Таймстампы
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    # Связи
    products = relationship("Product", back_populates="tenant")
    supplier_reports = relationship("SupplierReport", back_populates="tenant")