from app.celery_app import celery_app
from app.services.sync_service import SyncService
from app.database.database import SessionLocal
from app.models.tenant import Tenant
from datetime import date, datetime
import asyncio
import logging

logger = logging.getLogger(__name__)

@celery_app.task(bind=True, name='sync_tenant_wb_data')
def sync_tenant_wb_data(self, tenant_id: int, date_from: str, date_to: str):
    print(f"🔄 Starting sync for tenant {tenant_id} from {date_from} to {date_to}")
    """
    Универсальная фоновая задача для синхронизации данных WB за любой период
    """
    db = SessionLocal()
    
    try:
        logger.info(f"🚀 Starting Celery task for tenant {tenant_id}: {date_from} to {date_to}")
        
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if not tenant:
            logger.error(f"Tenant {tenant_id} not found")
            return {'status': 'error', 'message': 'Tenant not found'}
        
        if not tenant.wb_api_key:
            logger.error(f"WB API Key not configured for tenant {tenant_id}")
            return {'status': 'error', 'message': 'WB API Key not configured'}
        
        # Обновляем статус задачи
        self.update_state(
            state='PROGRESS',
            meta={
                'tenant_id': tenant_id,
                'status': 'Starting sync...'
            }
        )
        
        # Запускаем универсальную синхронизацию
        sync_service = SyncService()
        
        metrics = asyncio.run(sync_service.sync_wb_data_for_period(
            db=db,
            tenant=tenant,
            date_from=date.fromisoformat(date_from),
            date_to=date.fromisoformat(date_to)
        ))
        
        logger.info(f"✅ Celery task completed for tenant {tenant_id}: {metrics}")
        
        return {
            'status': 'success',
            'tenant_id': tenant_id,
            'period': f"{date_from} to {date_to}",
            'metrics': metrics,
            'completed_at': datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Celery task failed for tenant {tenant_id}: {e}")
        return {
            'status': 'error',
            'tenant_id': tenant_id,
            'error': str(e),
            'failed_at': datetime.utcnow().isoformat()
        }
    finally:
        db.close()