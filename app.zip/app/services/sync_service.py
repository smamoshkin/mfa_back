import time
import asyncio
from datetime import date
from typing import Dict
from sqlalchemy.orm import Session
from app.services.wb_api_client import WBAPIClient
from app.services.report_mapper import ReportMapperService
from app.crud.supplier_report_crud import bulk_create_reports
from app.models.tenant import Tenant
import logging

logger = logging.getLogger(__name__)

class SyncService:
    def __init__(self):
        self.wb_client = WBAPIClient()
        self.mapper = ReportMapperService()
    
    async def sync_wb_data_for_period(
        self,
        db: Session,
        tenant: Tenant,
        date_from: date,
        date_to: date
    ) -> Dict:
        """
        Синхронизация с пагинацией и пакетной вставкой
        Вставляет данные батчами по 100k
        """
        metrics = {
            'total_time': 0,
            'total_records': 0,
            'api_calls': 0,
            'batches_processed': 0,
            'last_rrdid': 0
        }
        
        start_time = time.time()
        rrdid = 0
        page = 1
        
        try:
            logger.info(f"🔄 Starting paginated sync for tenant {tenant.id} from {date_from} to {date_to}")
            
            while True:
                batch_metrics = await self._process_single_batch(
                    db=db,
                    tenant=tenant,
                    date_from=date_from,
                    date_to=date_to,
                    rrdid=rrdid,
                    page=page
                )
                
                metrics['total_records'] += batch_metrics['records_imported']
                metrics['api_calls'] += 1
                metrics['batches_processed'] += 1
                metrics['last_rrdid'] = batch_metrics['last_rrdid']
                
                # Если получили пустой массив - вероятно, данные кончились
                if batch_metrics['batch_size'] == 0:
                    logger.info("✅ Received empty array from API - sync completed!")
                    break
                
                # Подготавливаем следующий запрос
                rrdid = batch_metrics['last_rrdid']
                page += 1
                
                # Ждем 65 секунд перед следующим запросом
                logger.info("⏳ Waiting 65 seconds before next batch...")
                await asyncio.sleep(65)
                
            metrics['total_time'] = time.time() - start_time
            
            logger.info(f"""
🎯 PAGINATED SYNC COMPLETE:
├── Total time: {metrics['total_time']:.2f}s
├── Total records: {metrics['total_records']}
├── API calls: {metrics['api_calls']}
├── Batches processed: {metrics['batches_processed']}
└── Last rrdid: {metrics['last_rrdid']}
""")
            
            return metrics
            
        except Exception as e:
            metrics['total_time'] = time.time() - start_time
            logger.error(f"❌ Paginated sync failed after {metrics['total_time']:.2f}s: {str(e)}")
            raise
    
    async def _process_single_batch(
        self,
        db: Session,
        tenant: Tenant,
        date_from: date,
        date_to: date,
        rrdid: int,
        page: int
    ) -> Dict:
        """Обработка одного батча данных"""
        batch_metrics = {
            'batch_size': 0,
            'records_imported': 0,
            'last_rrdid': rrdid
        }
        
        logger.info(f"📦 Processing batch {page} (rrdid: {rrdid})")
        
        # 1. Запрос к API
        api_start = time.time()
        wb_data = await self.wb_client.get_report_detail_by_period(
            api_key=tenant.wb_api_key,
            date_from=date_from,
            date_to=date_to,
            rrdid=rrdid
        )
        api_time = time.time() - api_start
        
        if not wb_data:
            logger.info(f"ℹ️ Batch {page}: no data received")
            return batch_metrics
        
        batch_metrics['batch_size'] = len(wb_data)
        logger.info(f"✅ Batch {page}: received {len(wb_data)} records in {api_time:.2f}s")
        
        # 2. Маппинг
        mapping_start = time.time()
        reports_to_create = self.mapper.bulk_map_wb_reports(wb_data, tenant.id)
        mapping_time = time.time() - mapping_start
        
        if not reports_to_create:
            logger.warning(f"⚠️ Batch {page}: no valid reports after mapping")
            return batch_metrics
        
        logger.info(f"🔄 Batch {page}: mapped {len(reports_to_create)} records in {mapping_time:.2f}s")
        
        # 3. Вставка в БД
        db_start = time.time()
        records_imported = bulk_create_reports(db, reports_to_create)
        db_time = time.time() - db_start
        
        batch_metrics['records_imported'] = records_imported
        
        # 4. Получаем last_rrdid для следующего запроса
        if wb_data:
            last_rrdid = wb_data[-1].get('rrd_id')
            if last_rrdid:
                batch_metrics['last_rrdid'] = last_rrdid
        
        logger.info(f"💾 Batch {page}: inserted {records_imported} records in {db_time:.2f}s")
        
        return batch_metrics