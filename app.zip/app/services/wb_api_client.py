import aiohttp
import ssl
import certifi
from datetime import date
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class WBAPIClient:
    def __init__(self):
        self.base_url = "https://statistics-api.wildberries.ru/api/v5/supplier"
        
    async def get_report_detail_by_period(
        self, 
        api_key: str,
        date_from: date,
        date_to: date,
        limit: int = 100000,
        rrdid: int = 0
    ) -> List[Dict[str, Any]]:
        """
        ОДИН запрос к WB API /reportDetailByPeriod
        Возвращает до 100k записей
        """
        headers = {
            "Authorization": api_key
        }
        
        params = {
            "dateFrom": date_from.isoformat(),
            "dateTo": date_to.isoformat(),
            "limit": limit,
            "rrdid": rrdid
        }
        
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_context)
        
        try:
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(
                    f"{self.base_url}/reportDetailByPeriod",
                    headers=headers,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=61)
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"📥 Received {len(data)} records (rrdid: {rrdid})")
                        return data
                    elif response.status == 401:
                        raise Exception("Invalid API Key")
                    elif response.status == 429:
                        raise Exception("Rate limit exceeded")
                    else:
                        error_text = await response.text()
                        raise Exception(f"WB API error {response.status}: {error_text}")
                        
        except Exception as e:
            logger.error(f"WB API request failed: {str(e)}")
            raise