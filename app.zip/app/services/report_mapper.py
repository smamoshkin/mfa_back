from datetime import datetime
from typing import List, Dict, Any
from app.schemas.supplier_report import SupplierReportCreate

class ReportMapperService:
    """Сервис для преобразования сырых данных API в наши модели"""
    
    def map_wb_report_to_model(self, raw_data: Dict[str, Any], tenant_id: int) -> SupplierReportCreate:
        """
        Преобразует данные из WB API в нашу модель SupplierReportCreate
        Берет только нужные поля, остальное уходит в raw_data
        """
        
        # Извлекаем только нужные нам поля
        mapped_data = {
            'tenant_id': tenant_id,
            'realizationreport_id': raw_data.get('realizationreport_id'),
            'rrd_id': raw_data.get('rrd_id'),
            'date_from': self._parse_date(raw_data.get('date_from')),
            'date_to': self._parse_date(raw_data.get('date_to')),
            'sale_dt': self._parse_date(raw_data.get('sale_dt') or raw_data.get('rr_dt')),
            'sku': raw_data.get('sa_name'),  # 👈 sa_name → sku
            'doc_type_name': raw_data.get('doc_type_name', ''),
            'supplier_oper_name': raw_data.get('supplier_oper_name', ''),
            'quantity': raw_data.get('quantity', 0),
            'retail_amount': raw_data.get('retail_amount'),
            'amount_for_pay': raw_data.get('ppvz_for_pay'),  # 👈 ppvz_for_pay → amount_for_pay
            'retail_price': raw_data.get('retail_price'),
            'storage_fee': raw_data.get('storage_fee'),
            'bonus_type_name': raw_data.get('bonus_type_name', ''),
            'deduction': raw_data.get('deduction'),
            'delivery_rub': raw_data.get('delivery_rub'),
            'penalty': raw_data.get('penalty'),
            'acceptance': raw_data.get('acceptance'),
            'raw_data': raw_data  # 👈 ВСЕ оригинальные данные сохраняем здесь
        }
        
        # Очищаем None значения для обязательных полей
        if not mapped_data['sku']:
            mapped_data['sku'] = str(raw_data.get('nm_id', ''))  # Используем nm_id если нет sa_name
        
        return SupplierReportCreate(**mapped_data)
    
    def _parse_date(self, date_str: Any) -> datetime.date:
        """Парсит дату из строки"""
        if not date_str:
            return None
        try:
            if isinstance(date_str, str):
                # Пробуем разные форматы дат
                for fmt in ('%Y-%m-%d', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%dT%H:%M:%S'):
                    try:
                        return datetime.strptime(date_str, fmt).date()
                    except ValueError:
                        continue
            elif isinstance(date_str, datetime):
                return date_str.date()
        except (ValueError, TypeError):
            return None
        return None
    
    def bulk_map_wb_reports(self, raw_reports: List[Dict[str, Any]], tenant_id: int) -> List[SupplierReportCreate]:
        """Массовое преобразование отчетов WB"""
        mapped_reports = []
        
        for raw_report in raw_reports:
            try:
                mapped_report = self.map_wb_report_to_model(raw_report, tenant_id)
                mapped_reports.append(mapped_report)
            except Exception as e:
                # Логируем ошибки маппинга, но продолжаем обработку
                print(f"Error mapping report: {e}")
                continue
        
        return mapped_reports